<?php
/**
 * Template Name: Page result search
 * 
 * 
*/
get_header();
$txt_search=$_GET["text_search"];
$cat_Slug=$_GET["catSlug"];
$location=$_GET["location"];



// The Query
if($location==""){
    query_posts("s=$txt_search&cat=$cat_Slug");
}
else if($cat_Slug==""){
    query_posts("s=$txt_search&cat=$location");
}
else if($cat_Slug=="" && $location==""){
    query_posts("s=$txt_search");
}
else if($txt_search==""){
    query_posts("category__and=$cat_Slug,$location");
}
else if($txt_search=="" && $location=""){
    query_posts("cat=$cat_Slug");
}
else if($txt_search=="" && $cat_Slug=""){
    query_posts("cat=$location");
}
else{
query_posts("s=$txt_search&category__and=$cat_Slug,$location");
}

// The Loop
while ( have_posts() ) : the_post();
    ?>
          <div id="contentwrapper">
            <div id="contentcolumn">
            <?php dynamic_sidebar('ads_content1');?>
	       

			        
                                  
            </div>
           
        </div>
          
    <?php
endwhile;

// Reset Query
wp_reset_query();

?>
<div id="leftcolumn" style="min-height:3050px;">
            <?php get_sidebar('left');?>
        </div>   
        <div id="rightcolumn">
            <?php get_sidebar('right');?>
        </div>
        
<?php
get_footer(); 
?>