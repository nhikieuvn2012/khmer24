=== Facebook Like Box Widget ===
Contributors: sunwu2007
Donate link: http://bit.ly/9Njzpo
Tags: facebook, facebook like, facebook badge, facebook button, facebook like button, fb like, facebook like box, badge, social network, seo, increase traffic, BuddyPress
Requires at least: 2.8.6
Tested up to: 3.7.1
Stable tag: trunk

== Description ==
Facebook Like Box Widget is a social plugin that enables Facebook Page owners to attract and gain Likes & Recommendation Comments from their own website. The Like Box enables users to: see how many users already like this page, and which of their friends like it too, read recent posts from the page and Like the page with one click, without needing to visit the page.


== Installation ==

* Download "facebook-like-box-widget.zip" to your computer.
* Login as administrator
* Click on Plugins --> Add New
* On "Install Plugins" page, clik on "Upload" 
* Browse and select "facebook-like-box-widget.zip" and click on "Install Now"
* You can activate it now
* Finally, add the widget to your sidebar through the 'Appearance > Widgets' menu
* Go to your widget and adjust the settings

or visit author website for Facebook Like Box tutorial.

== Frequntly Asked Qustions ==
[Visit](http://vivociti.com/)

== Screenshots ==

1. Wordpress Admin Setting for Facebook Like Box 
2. Wordpress Admin Setting for Integration to display Social Network Buttons (Default is NO)
3. Wordpress Admin Setting for Integration to display Twitter Counter & Twitter Signature (Default is NO) 
4. Wordpress Front Page Display (with streams)
5. Wordpress Front Page Display (no streams)
6. Now you can enable additional social network buttons such as Pinterest, Twitter, Google+ and it is floating on the left or right side with 6 styles for you to choose (default is set to No). It is powered by AddThis.com.
7. From Version 2.7 now another additional integration to display Twitter Counter & Twitter Signature from your Twitter profile. Can be positioned before or after Facebook Like Box & Facebook Like Button

== Changelog ==

= v1.0 05.25.2010 =
initial release

= v1.1 06.11.2010 =
minor fix to update stream setting

= v1.2 09.09.2010 =
minor fix to title

= v1.5 02.10.2011 =
Enhanced with Show Faces Option and Color Scheme Option

= v1.5.1 02.26.2011 =
Minor changes

= v1.6 02.27.2011 =
Minor changes & tested for Wordpress 3.1

= v1.7 03.02.2011 =
Fixed small bug in if condition & show faces

= v1.8 03.06.2011 =
Major fixes for showing faces and streams & enhancement to include Facebook Like and Recommend Button, and to support XFBML rendering

= v1.9 05.02.2011 =
Minor enhancement for administration page

= v2.0 06.04.2011 =
Minor enhancement

= v2.1 08.15.2011 =
Tested with Wordpress 3.2.1

= v2.2 12.15.2011 =
Support with Border Color following Facebook Developer update

= v2.3 03.17.2012 =
Removed support for iFrame per Wordpress Team feedback

= v2.4 08.05.2012 =
* Now you can enable additional social network buttons such as Pinterest, Twitter, Google+ and it is floating on the left side (default is set to No).
* Leave Title field blank will not show default title anymore

= v2.5 09.05.2013 =
* Tested on Wordpress 3.5.2

= v2.6 09.10.2013 =
* Remove minor option from Setting per Wordpress Plugin Team feedback

= v2.7 11.19.2013 =
* Fix minor bug for Social Buttons from AddThis Integration
* Add 3 more styles for floating Social Buttons 
* Enhance with Twitter Signature & Twitter Counter & Twitter Follow QR Code Integration
* Tested with Wordpress 3.7.1
