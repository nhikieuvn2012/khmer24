<?php

interface I_Component_Factory
{
    
}