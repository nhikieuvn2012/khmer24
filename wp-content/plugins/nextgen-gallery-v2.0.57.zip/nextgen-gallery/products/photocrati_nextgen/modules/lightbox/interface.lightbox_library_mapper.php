<?php

interface I_Lightbox_Library_Mapper
{

}