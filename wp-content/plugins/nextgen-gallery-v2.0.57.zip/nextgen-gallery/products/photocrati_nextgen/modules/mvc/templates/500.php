<html>
    <head>
        <title>Error 500 <?php echo_h($message) ?></title>
    </head>    
    <body>
        <h1>Error: <?php echo_h($message) ?></h1>
        <p>You requested something the server doesn't understand.</p>
    </body>
</html>