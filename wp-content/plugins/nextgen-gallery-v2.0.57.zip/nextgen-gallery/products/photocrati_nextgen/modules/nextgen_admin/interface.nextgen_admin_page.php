<?php

interface I_NextGen_Admin_Page
{
	function enqueue_backend_resources();
}