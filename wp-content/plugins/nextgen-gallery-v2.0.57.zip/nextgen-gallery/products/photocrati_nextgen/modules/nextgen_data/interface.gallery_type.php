<?php

interface I_Gallery_Type extends I_Component_Config
{
}