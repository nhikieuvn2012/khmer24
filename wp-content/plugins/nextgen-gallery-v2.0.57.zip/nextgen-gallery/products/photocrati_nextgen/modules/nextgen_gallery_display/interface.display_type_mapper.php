<?php

interface I_Display_Type_Mapper
{
	
}