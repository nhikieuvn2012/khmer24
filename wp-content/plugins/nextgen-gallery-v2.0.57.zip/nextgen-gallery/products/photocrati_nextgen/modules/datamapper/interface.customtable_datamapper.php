<?php

interface I_CustomTable_DataMapper
{
	
}