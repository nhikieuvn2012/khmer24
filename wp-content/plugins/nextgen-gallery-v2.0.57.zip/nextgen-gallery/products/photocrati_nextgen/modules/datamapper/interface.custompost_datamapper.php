<?php

interface I_CustomPost_DataMapper
{
	
}