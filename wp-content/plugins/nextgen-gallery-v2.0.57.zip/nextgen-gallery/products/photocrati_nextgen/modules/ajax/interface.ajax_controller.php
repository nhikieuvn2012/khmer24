<?php

interface I_Ajax_Controller extends I_MVC_Controller
{
	
}