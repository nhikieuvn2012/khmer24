<?php

interface I_Attach_To_Post_Controller
{
	function index_action();
}