<form rel="<?php echo esc_attr($display_type_name) ?>" class="<?php echo esc_attr($css_class) ?>" method='POST' action='<?php echo esc_attr($_SERVER['REQUEST_URI'])?>'>
	<?php echo $settings ?>
</form>